package com.example.powerbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PowerbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
